import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-httpcall',
  templateUrl: './httpcall.component.html',
  styleUrls: ['./httpcall.component.css']
})
export class HttpcallComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
