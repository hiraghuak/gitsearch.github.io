import { MycolDirective } from './mycol.directive';

describe('MycolDirective', () => {
  it('should create an instance', () => {
    const directive = new MycolDirective();
    expect(directive).toBeTruthy();
  });
});
