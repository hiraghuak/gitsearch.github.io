import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dbpage',
  templateUrl: './dbpage.component.html',
  styleUrls: ['./dbpage.component.css']
})
export class DbpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
