import { MybossDirective } from './myboss.directive';

describe('MybossDirective', () => {
  it('should create an instance', () => {
    const directive = new MybossDirective();
    expect(directive).toBeTruthy();
  });
});
